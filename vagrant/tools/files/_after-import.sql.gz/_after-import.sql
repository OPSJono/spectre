COMMIT;
SET autocommit=1;
